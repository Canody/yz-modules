# __init__.py
from .bar_grad import bar_grad
from .hex2rgb import hex2rgb
from .grad_cmap import grad_cmap
